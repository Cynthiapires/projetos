import 'app.dart';
import 'package:flutter/material.dart';

main() => runApp(const MaterialApp(
  home: Home(),
));